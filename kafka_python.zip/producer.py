
#!/usr/local/bin/python
#
# =============================================================================
#
# Produce messages to Confluent Cloud
# Using Confluent Python Client for Apache Kafka
#
# =============================================================================

from typing import List
from confluent_kafka import Producer, KafkaError
import sys
import json
import parser_lib
import random
from faker import Faker
from datetime import datetime, tzinfo, timezone
import pytz

# rxsummary-ndc_filter_out'
vscode_run_args = '--file consumer.dev.properties --topic dev-eapi-rxsummary-ndc_filter_out'
delivered_records = 0

# Optional per-message on_delivery handler (triggered by poll() or flush())
# when a message has been successfully delivered or permanently failed delivery (after retries).


def acked(err, msg):
    global delivered_records
    """
    Delivery report handler called on successful or failed delivery of message
    """
    if err is not None:
        print("Failed to deliver message: {}".format(err))
    else:
        delivered_records += 1
        print(
            f"Produced record to topic {msg.topic()} partition [{msg.partition()}] @ offset {msg.offset()} [msg] -> {json.dumps(json.loads(msg.value()))}")


if __name__ == '__main__':
    fake = Faker()

    # Read arguments and configurations and initialize
    if len(sys.argv) == 1:  # fix the glitch with vscode run vs debug
        args = parser_lib.parse_args(vscode_run_args)
        if not args.quiet:
            print(
                f"Using module {sys.argv[0].split('/')[-1]} arguments: {vscode_run_args}")
    else:
        args = parser_lib.parse_args()
    config_file = args.config_file
    conf = parser_lib.read_cc_config(config_file)

    topic = args.topic

    # Create Producer instance
    producer_conf = parser_lib.pop_schema_registry_params_from_config(conf)
    print(f"producer_conf: \n{json.dumps(producer_conf, indent=4)}\n")
    producer = Producer(producer_conf)

    mfgName: List[str] = ['MODERNA', 'PFIZER-BIONTECH', 'JANSSEN', 'JANSSEN', 'MODERNA', 'PFIZER-BIONTECH']
    # --> disNdc: List[str] = ['']
    # '59140001852', '59140001853', '59140001855', '59140001859', '59140001864',
    patIds: List[str] = ['59140001848', '59140001849', '59140001850', '59140001851', '59140001854', '59140001856', '59140001857',
                         '59140001858', '59140001860', '59140001861', '59140001862', '59140001863', '59140001865', '59140001866', '59140001868']

    i: int = 0
    with open("./test_events_ravi_7.txt", mode='r', encoding='utf-8') as fh:
        for event in fh:
            event = event.strip()
            # -> pretty print event... print(f"{json.dumps(json.loads(event), indent=4)}")
            # -> random.choice(patIds) #str(fake.random_number(digits=13, fix_len=True))
            # key = patIds[i]  
            key = '59140001850' # '59140001848'
            val = json.loads(event)
            now: str = datetime.now(tz=pytz.timezone('US/Central')).strftime("%Y-%m-%d %H:%M:%S")

            val['fills'][0][0]['PAT_ID'] = key
            # val['fills'][0][0]['RX_DENIAL_OVERRIDE_CD'] = random.choice(['02', '06', '07', '10'])
            val['fills'][0][0]['FILL_SOLD_DTTM'] = now

            # -> pretty print event... 
            print(f"{json.dumps(val, indent=2)}")

            msg = json.dumps(val)
            i += 1

            producer.produce(topic, key=key, value=msg, on_delivery=acked)
            # p.poll() serves delivery reports (on_delivery) from previous produce() calls.
            producer.poll(0)
            # if i >= 0:
            #     break

    producer.flush()

    print("{} messages were produced to topic {}!".format(delivered_records, topic))
