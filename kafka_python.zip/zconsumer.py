#!/usr/bin/python3
# 
# #from kafka import KafkaConsumer  #, KafkaProducer
from avro.io import DatumReader, BinaryDecoder
import avro.schema
import kafka
import ssl
import logging
import json

#logging.basicConfig(level=logging.DEBUG)
import io

# schema = avro.schema.parse(open("./optin.avsc", "r").read())
# schema = avro.schema.parse(open("./rxstatuschange.avsc", "r").read())
# reader = DatumReader(schema)

# def decode(offset, msg_value):
#     out_file = open(f"rx/optin-{offset}", "wb") # open for [w]riting as [b]inary
#     out_file.write(msg_value)
#     out_file.close()
#     message_bytes = io.BytesIO(msg_value)
#     message_bytes.seek(5)
#     decoder = BinaryDecoder(message_bytes)
#     event_dict = reader.read(decoder)
#     return event_dict

try:
    #topic = "sit-eapi-customer-cdc-cdi_mmca_cv_member"
    # topic = 'dev-eapi-rxstatuschange-fill_status' 
    #topic = 'sit-eapi-cdp-ec_profile_il'
    topic = 'dev-eapi-cdp-lr_optin_il'
    sasl_mechanism = "PLAIN"
    security_protocol = "SASL_SSL"
    dev_broker = ['pkc-42nky.eastus2.azure.confluent.cloud:9092']
    dev_username = "5VMOCG3F26UC2IOO"
    dev_password = "2Iz5ZmkiU8JSQMmh5+yXTFKRZ5El+vL/kfgg1Nj/gzB0sz5D7Aq+ATLhWCEXdkEl"
    sit_broker = ['pkc-e0mm2.eastus2.azure.confluent.cloud:9092']
    sit_username = "GP6XXMNBYST6DW3T"
    sit_password = "vKRQpWPESMaWHOgc5pRzB7td7TOxLx8JK0wu4/ApL3jhQ5dm+Ls3KvS6yKZvLVpC"
    context = ssl.create_default_context()
    context.options &= ssl.OP_NO_TLSv1
    context.options &= ssl.OP_NO_TLSv1_1

    consumer = kafka.KafkaConsumer( group_id='g8-group',
                                    bootstrap_servers=dev_broker,
                                    api_version=(1, 0, 0),
                                    security_protocol=security_protocol,
                                    ssl_context=context,
                                    ssl_check_hostname=True,
                                    sasl_mechanism = sasl_mechanism,
                                    sasl_plain_username = dev_username,
                                    sasl_plain_password = dev_password,
                                    auto_offset_reset='earliest',
                                    enable_auto_commit=False
                                )
                            # lambda m: json.loads(m.decode('utf-8'))
                            # value_deserializer=lambda m: json.loads(m.decode('utf-8')))

    # print(f'{consumer.topics()}')
    print(f"partitions: {consumer.partitions_for_topic(topic)}")
    tp0 = kafka.TopicPartition(topic, 0) 
    tp1 = kafka.TopicPartition(topic, 1)
    tp2 = kafka.TopicPartition(topic, 2)
    tp3 = kafka.TopicPartition(topic, 3)
    tp4 = kafka.TopicPartition(topic, 4)
    tp5 = kafka.TopicPartition(topic, 5)
    tp6 = kafka.TopicPartition(topic, 6)
    tp7 = kafka.TopicPartition(topic, 7)
    tp8 = kafka.TopicPartition(topic, 8)
    tp9 = kafka.TopicPartition(topic, 9)        
    partitions = [tp0, tp1, tp2, tp3, tp4, tp5, tp6, tp7, tp8, tp9]             
    # partitions = [tp0, tp1, tp2, tp3, tp4, tp5]

    consumer.assign(partitions)
    consumer.seek_to_beginning(tp0, tp1, tp2, tp3, tp4, tp5, tp6, tp7, tp8, tp9)

    count = 0
    for message in consumer:
        # message value and key are raw bytes -- decode if necessary!
        # e.g., for unicode: `message.value.decode('utf-8')`
        # msg = json.dumps(message.value['message']['data'], indent=4)
        print(f"key: {message.key()}")
        # msg = decode(message.offset, message.value)
        # print(f"{message.topic}[{message.partition}@{message.offset}] key:{message.key}, value:\n{json.dumps(msg, indent=4)}")
        # print(f"{message.topic}[{message.partition}@{message.offset}] value: {json.dumps(msg['eventType'])}")
        count += 1
        if count > 10: break
        #consumer.commit()
        
except Exception as e:
    print(e)

exit()
