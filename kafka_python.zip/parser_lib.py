#!/usr/bin/python3

from typing import Dict
import argparse

def parse_args(vscode_run_args: str = None):
    """Parse command line arguments"""

    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--file'     , help="path to configuration file", dest="config_file", metavar='file', required=True)
    parser.add_argument('-t', '--topic'    , help="topic name", dest="topic", metavar="topic", required=True)
    parser.add_argument('-p', '--partition', help="read from partition", dest="partition", metavar='#', type=int, required=False, default=argparse.SUPPRESS)
    parser.add_argument('-o', '--offset'   , help="read from offset", dest="offset", metavar='#', type=int, required=False, default=argparse.SUPPRESS)
    parser.add_argument('-n', '--messages' , help='read # of messages from specified <partition> and <offset>', dest='num_messages', metavar='#', type=int, default=0, required=False)
    parser.add_argument('-g', '--group'    , help="set group.id", dest="group", metavar='group', type=str, default=None, required=False)
    parser.add_argument('-v', '--verbose'  , help="enable verbose mode", action='store_true',  required=False)
    parser.add_argument('-q', '--quiet'    , help="produces only messages output suitable for logging, omitting progress indicators.", dest='quiet', action='store_true',  required=False)

    if vscode_run_args:
        args = parser.parse_args(vscode_run_args.split())
    else:
        args = parser.parse_args()

    if args.verbose:
        print(f"{args}")

    return args


def read_cc_config(config_file) -> Dict[str,str]:
    """Read Confluent Cloud configuration for librdkafka clients"""

    conf: Dict[str,str] = {}
    with open(config_file, mode = 'r', encoding='utf-8') as fh:
        for line in fh:
            line = line.strip()
            if len(line) != 0 and line[0] != "#":
                parameter, value = line.strip().split('=', 1)
                conf[parameter] = value.strip()

    return conf

def pop_schema_registry_params_from_config(conf):
    """Remove potential Schema Registry related configurations from dictionary"""

    conf.pop('kafka.environement', None)
    conf.pop('schema.registry.url', None)
    conf.pop('basic.auth.user.info', None)
    conf.pop('basic.auth.credentials.source', None)
    conf.pop('schema.registry.basic.auth.user.info', None)

    return conf

def schema_registry_params_from_config(conf):
    """Remove potential Schema Registry related configurations from dictionary"""

    conf.pop('kafka.environement', None)
    conf.pop('bootstrap.servers', None)
    conf.pop('security.protocol', None)
    conf.pop('sasl.mechanisms', None)
    conf.pop('sasl.username', None)
    conf.pop('sasl.password', None)

    return conf