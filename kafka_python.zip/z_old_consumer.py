#!/workspaces/kafka-python/.venv-container/bin/python
# /usr/local/bin/python
## /usr/bin/python3

# =============================================================================
#
# Consume messages from Confluent Cloud
# Using Confluent Python Client for Apache Kafka
# Reads Avro data, integration with Confluent Cloud Schema Registry
#
# =============================================================================

# from avro.schema import DEBUG_VERBOSE
from typing import Dict, List
import sys
import uuid
import socket
from datetime import datetime, tzinfo, timezone
# import pytz
from time import time

from confluent_kafka import OFFSET_INVALID, OFFSET_BEGINNING
from confluent_kafka import Consumer, DeserializingConsumer, Message, TopicPartition
from confluent_kafka.admin import ClusterMetadata, BrokerMetadata, TopicMetadata, PartitionMetadata
from confluent_kafka.serialization import Deserializer, StringDeserializer, SerializationContext, MessageField

from confluent_kafka.avro.serializer import SerializerError
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.error import SchemaRegistryError
from confluent_kafka.schema_registry.avro import AvroDeserializer
from confluent_kafka.schema_registry.schema_registry_client import RegisteredSchema

from colorama import Fore, Back, Style
import json
import parser_lib
import logging
import pytz

logging.basicConfig(level=logging.ERROR)
# log = logging.getLogger(__name__)

# vscode_run_args = '--file consumer.prod.properties --group id.48 --messages 100000 --topic prod-eapi-rxsummary-ndc_filter_out --quiet'
# vscode_run_args = '--file consumer.prod.properties --group id.48 --messages 100 --topic prod-eapi-cdp-lr_profile_purged_il'
vscode_run_args = '--file consumer.prod.properties --group id.48 --messages 100 --topic prod-eapi-cdp-lr_profile_il'
# vscode_run_args = '--file consumer.prod.properties --group id.48 --messages 10 --topic prod-eapi-cdp-cdi_mpi_memhead_il'


def get_deserializer(subject: str, conf: dict) -> Deserializer:
    """ 
    checks if schema exists: if schema exists return AvroDeserializer else return StringDeserializer 

    Args: 
        subject (str): Subject refers to either a “<topic>-key” or “<topic>-value” depending on whether you are lookig for the key schema or the value schema
    """

    # get schema kind from subject, i.e. key || value
    kind = subject.split('-')[-1]

    # set default Deserializer
    deserializer = StringDeserializer(codec='utf_8')

    # schema registry configuration...
    schema_registry_conf = {
        'url': conf['schema.registry.url'],
        'basic.auth.user.info': conf['schema.registry.basic.auth.user.info']
    }
    schema_registry_client: SchemaRegistryClient = SchemaRegistryClient(schema_registry_conf)

    # check if schema is in SchemaRegistry otherwise we use default StringDeserializer
    try:
        schema = schema_registry_client.get_latest_version(subject)
        deserializer = AvroDeserializer(schema_registry_client, schema.schema.schema_str)

        if args.verbose:
            print(f"Using AvroDeserializer with {kind}-schema: \n{json.dumps(json.loads(schema.schema.schema_str), indent=4)}")
        elif not args.quiet:
            print(f"{Fore.CYAN}Using AvroDeserializer with {kind}-schema: subject={schema.subject}, id={schema.schema_id}, version={schema.version}.{Style.RESET_ALL}")
    except TypeError:
          if not args.quiet:
            print(f"{Fore.CYAN}Using StringDeserializer, {kind}-schema: subject={subject} not in SchemaRegistry.{Style.RESET_ALL}")
    except SchemaRegistryError:
        if not args.quiet:
            print(f"{Fore.CYAN}Using StringDeserializer, {kind}-schema: subject={subject} not in SchemaRegistry.{Style.RESET_ALL}")

    return deserializer


def on_assign(consumer, partitions: List[TopicPartition]) -> None:
    """ handling of offsets on completion of a successful partition re-assignment """
    # Query committed offsets for this group and the given partitions
    committed: List[TopicPartition] = None
    committed = consumer.committed(partitions, timeout=10.0)

    # for all commited partitions...
    for p in committed:
        # Get the partition low, high watermarks and "group.id" partition offset.
        (lo, hi) = consumer.get_watermark_offsets(p, timeout=10, cached=False)
        offset = '-' if p.offset == OFFSET_INVALID else p.offset
        lag = "no hwmark" if hi < 0 else (
            (hi - lo) if p.offset < 0 else (hi - p.offset))
        if not args.quiet:
            print(
                f"{Fore.LIGHTYELLOW_EX}Partition: {Fore.MAGENTA}{p.partition}@[offset: {offset: <10}, lo: {lo: <10}, hi: {hi: <10}, lag: {lag: <10}]{Style.RESET_ALL}")


def consume_topic_partition(topic: str, partition: int, offset: int, num_messages: int) -> None:
    if topic and partition and offset:
        tp = TopicPartition(topic, partition, offset)
        consumer.assign([tp])

        messages = consumer.consume(num_messages)
        for msg in messages:
            key = key_deserializer.__call__(msg.key(), None)
            val = val_deserializer.__call__(msg.value(), None)
            print(f"p@[o]: {msg.partition()}@[{msg.offset()}] ", end=" ")
            print(f"key: {key}")
            print(f"value: {json.dumps(val, indent=4)}")

        consumer.close()

# '.fills[][] | {FILL_SOLD_DTTM, SOLD_LOCAL_DTTM, RX_DENIAL_OVERRIDE_CD, GENERAL_MFG_NAME, DISPENSED_NDC, DRUG_ID}'
# {"rx.PAT_ID": .rx.PAT_ID, storeNumber: .storeNumber, FILL_ENTERED_DTTM: .rx.FILL_ENTERED_DTTM, FILL_SOLD_DTTM: .fills[][].FILL_SOLD_DTTM, SOLD_LOCAL_DTTM: .fills[][].SOLD_LOCAL_DTTM, RX_DENIAL_OVERRIDE_CD: .fills[][].RX_DENIAL_OVERRIDE_CD, GENERAL_MFG_NAME: .fills[][].GENERAL_MFG_NAME, DISPENSED_NDC: .fills[][].DISPENSED_NDC, DRUG_ID: .fills[][].DRUG_ID DRUG_NAME: .fills[][].DRUG_NAME}


# main entry
if __name__ == '__main__':

    # Read arguments and configurations and initialize
    if len(sys.argv) == 1:  # fix the glitch with vscode run vs debug
        args = parser_lib.parse_args(vscode_run_args)
        if not args.quiet:
            print(
                f"Using module {sys.argv[0].split('/')[-1]} arguments: {vscode_run_args}")
    else:
        args = parser_lib.parse_args()
    config_file = args.config_file
    conf = parser_lib.read_cc_config(config_file)

    if args.verbose:
        print(f"{Fore.BLUE}Kafka Consumer Cofiguration: {Style.RESET_ALL}\n{json.dumps(conf, indent=4)}")

    # topic = 'sit-eapi-rxsummary-ndc_filter_out'
    topic = args.topic

    # => curl -u U4ZXASJVWQZQGEU7:SAozASmRuc0Pp6b8Wbr6BSjNRdiM9qcHt1d0EuRsN33Vwu95jAjTVnTDKwBdq19q https://psrc-4r0k9.westus2.azure.confluent.cloud/subjects/sit-eapi-cdp-ec_profile_il-value/versions/2
    key_deserializer = get_deserializer(topic + "-key", conf)
    val_deserializer = get_deserializer(topic + "-value", conf)

    # for full list of configurations, see: https://docs.confluent.io/current/clients/confluent-kafka-python/#deserializingconsumer
    group: str = args.group if args.group is not None else str(uuid.uuid1())
    consumer_conf = {
        'bootstrap.servers': conf['bootstrap.servers'],
        'sasl.mechanism': conf['sasl.mechanisms'],
        'security.protocol': conf['security.protocol'],
        'sasl.username': conf['sasl.username'],
        'sasl.password': conf['sasl.password'],
        # 'key.deserializer': key_deserializer,
        # 'value.deserializer': val_deserializer,
        # 'debug': 'all', #generic, broker, topic, metadata, feature, queue, msg, protocol, cgrp, security, fetch, interceptor, plugin, consumer, admin, eos, mock, all
        'group.id': group,
        'enable.auto.commit': False,
        'api.version.request': True,
        'client.id': socket.gethostname(),
        # 'auto.offset.reset': 'latest'
        'auto.offset.reset': 'earliest'
    } 

    #-> instantiate consumer...
    consumer = Consumer(consumer_conf)

    # consume # messages from topic, partition and offset...exit when done
    # if args.topic and args.partition and args.offset:
    #     consume_topic_partition(args.topic, args.partition, args.offset, args.num_messages)
    #     exit()

    # consumer.assign(partitions)
    # for i in range(100):
    #     message = consumer.consume()[0]
    #     key = key_deserializer.__call__(message.key(), None)
    #     val = val_deserializer.__call__(message.value(), None)
    #     print(f"p@[o]: {message.partition()}@[{message.offset()}] ", end=" ")
    #     print(f"key: {key}")

    # consumer.close()
    # exit()

    # Subscribe to topic
    if not args.quiet:
        print(f"Subscribing to {Fore.GREEN}topics: {topic}, group.id: {group}{Style.RESET_ALL}")
    consumer.subscribe([topic], on_assign=on_assign)

    # Process messages
    count: int = 0
    events: int = 0
    start_time = time()

    timeout = 1.0
    while True:
        try:
            message: Message = consumer.poll(timeout)

            elapsed_seconds = time() - start_time
            if (elapsed_seconds >= 60):
                now_iso: str = datetime.now(tz=pytz.timezone('US/Central')).isoformat(sep=' ', timespec='seconds')
                events_per_sec = events / elapsed_seconds
                print(f"{Fore.YELLOW}{now_iso}: {Fore.GREEN}events/min -> {events*(60.0/elapsed_seconds):.0f}, {Fore.MAGENTA}events/sec -> {events_per_sec:.2f}{Style.RESET_ALL}")
                events = 0
                start_time = time()


            if message is None:
                # No message available within timeout.
                # Initial message consumption may take up to `session.timeout.ms` for the consumer group to rebalance and start consuming
                # print("Waiting for message or event/error in poll()")
                continue
            elif message.error():
                print('error: {}'.format(message.error()))
            else:
                count += 1 #-> count for received messages...

                #-> message metadata details...i.e. partition, offset, timestemp, etc...
                p:   int = message.partition()
                o:   int = message.offset()
                ts_type, timestamp = message.timestamp()
                ts_type_str = 'TIMESTAMP_NOT_AVAILABLE' if ts_type == 'TIMESTAMP_NOT_AVAILABLE' else (
                    'TIMESTAMP_CREATE_TIME' if ts_type == 'TIMESTAMP_CREATE_TIME' else 'TIMESTAMP_LOG_APPEND_TIME')

                #-> key and msg deserialization....
                key: str = key_deserializer.__call__(message.key(), None)
                msg: str = val_deserializer.__call__(message.value(), None)

                #-> 
                msg_json: str = json.dumps(msg, ensure_ascii=False, indent=4)
                dt_iso: str = datetime.fromtimestamp(timestamp / 1000.0, tz=timezone.utc).isoformat()
                if not args.quiet:
                    print(
                        f"\n{Fore.CYAN}*=> Consumed msg from partitio@[offset]: {p}@[{o}], type: {ts_type_str}, timestamp: {timestamp}, UTC: {dt_iso}{Style.RESET_ALL}\n{msg_json}")
                else: #-> print msg
                    print(f"{msg_json}")
                    # pass

                if args.num_messages != 0 and count >= args.num_messages:
                    if not args.quiet:
                        print(f"Read {count} messages. We are done.")
                    break
        except KeyboardInterrupt:
            break
        except SerializerError as e:
            # Report malformed record, discard results, continue polling
            print("Message deserialization failed {}".format(e))
            pass

    # Leave group and commit final offsets
    consumer.close()
