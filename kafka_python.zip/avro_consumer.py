#!/usr/local/bin/python
# /usr/local/bin/python
# /usr/bin/python3

# =============================================================================
#
# Consume messages from Confluent Cloud
# Using Confluent Python Client for Apache Kafka
# Reads Avro data, integration with Confluent Cloud Schema Registry
#
# =============================================================================

#rem from avro.schema import DEBUG_VERBOSE
from typing import Dict, List
import sys
import uuid
import socket
from datetime import datetime, timezone
import logging
from time import time
import json
import pytz

from confluent_kafka.admin import ClusterMetadata, TopicMetadata

from confluent_kafka import OFFSET_INVALID
#rem from confluent_kafka import OFFSET_BEGINNING
from confluent_kafka import Consumer, Message, TopicPartition
from confluent_kafka.error import KafkaError, KafkaException
from confluent_kafka.serialization import Deserializer, SerializationContext, MessageField

from confluent_kafka.avro.serializer import SerializerError
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.error import SchemaRegistryError
from confluent_kafka.schema_registry.avro import AvroDeserializer
#rem from confluent_kafka.schema_registry.schema_registry_client import RegisteredSchema

from colorama import Fore, Back, Style
import parser_lib

logging.basicConfig(level=logging.ERROR)

#-> consime n messages from topic...
vscode_run_args = '--file consumer.dev.properties --group dev_grp_id.101 --messages 1251 --topic dev-eapi-cdp-lr_optin_il --quiet' # --verbose'
#-> vscode_run_args = '--file consumer.sit.properties --group sit_grp_id.101 --messages 2000 --topic sit-eapi-cdp-lr_optin_il --quiet' # --verbose'

#-> consume n messages from topic on partition from offset...
# vscode_run_args = '--file consumer.dev.properties -g dev_grp_id.101 -n 2 -t dev-eapi-cdp-lr_optin_il -p 1' # --verbose'

# Read arguments and configurations and initialize
if len(sys.argv) == 1:  # fix the glitch with vscode run vs debug
    args = parser_lib.parse_args(vscode_run_args)
    if not args.quiet:
        print(f"Using module {sys.argv[0].split('/')[-1]} arguments: {vscode_run_args}")
else:
    args = parser_lib.parse_args()

# -> we need a topic and a group..
topic: str = args.topic 
group: str = args.group if args.group is not None else str(uuid.uuid1())

#-> get config...
config_file = args.config_file
config_dict = parser_lib.read_cc_config(config_file)

# for full list of configurations, see: https://docs.confluent.io/current/clients/confluent-kafka-python/#deserializingconsumer
consumer_conf = {
    'bootstrap.servers': config_dict['bootstrap.servers'],
    'sasl.mechanism': config_dict['sasl.mechanisms'],
    'security.protocol': config_dict['security.protocol'],
    'sasl.username': config_dict['sasl.username'],
    'sasl.password': config_dict['sasl.password'],
    # 'debug': 'all', #generic, broker, topic, metadata, feature, queue, msg, protocol, cgrp, security, fetch, interceptor, plugin, consumer, admin, eos, mock, all
    'group.id': group,
    'enable.auto.commit': False,
    'api.version.request': True,
    'enable.partition.eof': True, #-> If set to True, partition EOF events will be exposed as Messages with error().code() set to _PARTITION_EOF
    'client.id': socket.gethostname(),
    'auto.offset.reset': 'earliest' #'latest'
}

if args.verbose:
    print(f"{Fore.BLUE}Kafka Consumer Cofiguration: {Style.RESET_ALL}\n{json.dumps(config_dict, indent=2)}")

def get_avro_deserializer(conf: dict) -> Deserializer:
    # schema registry configuration...
    schema_registry_conf = {
        'url': conf['schema.registry.url'],
        'basic.auth.user.info': conf['schema.registry.basic.auth.user.info']
    }
    schema_registry_client: SchemaRegistryClient = SchemaRegistryClient(schema_registry_conf)

    #-> 
    return AvroDeserializer(schema_registry_client)

def on_assign(consumer, partitions: List[TopicPartition]) -> None:
    """ handling of offsets on completion of a successful partition re-assignment """

    #-> Query committed offsets for this group and the given partitions...
    committed: List[TopicPartition] = consumer.committed(partitions, timeout=10.0)

    # for all commited partitions...
    topic_lag: int = 0
    for _p in committed:
        # Get the partition low, high watermarks and "group.id" partition offset.
        (lo, hi) = consumer.get_watermark_offsets(_p, timeout=10, cached=False)
        offset = '-' if _p.offset == OFFSET_INVALID else _p.offset
        
        #-> lag = "no hwmark" if hi < 0 else ((hi - lo) if _p.offset < 0 else (hi - _p.offset))
        if hi < 0:
            lag = "no hwmark" # Unlikely
        elif _p.offset < 0:
            # No committed offset, show total message count as lag. 
            # The actual message count may be lower due to compaction and record deletions.
            lag = (hi - lo)
        else:
            lag = (hi - _p.offset)

        #-> topic_lag: current lag accross all partitions for this consumer group...
        topic_lag += lag

        #-> do tell us where we are with offsets and lags...
        print(f'{_p.topic} [{_p.partition}] @ [{offset.center(10," ")}], lo: [{lo: <10}], hi: [{hi: <10}], lag: [{lag: <10}]')

    #-> what is the current lag accross all partitions (lag for the topic)...
    print(f'{Fore.LIGHTRED_EX}-> Total lag for consumer group: {group} on topic: {topic} -> {topic_lag}{Style.RESET_ALL}')

def consume_topic_partition(args) -> None:

    if ('partition' in args) and ('offset' in args):
        print(f"Consumer assigned to topics -> {topic} with group.id: {group} on p@[o]: {args.partition}@[{args.offset}] to fetch {args.num_messages} messages")
        tp = TopicPartition(topic, args.partition, args.offset)
    elif ('partition' in args) and ('offset' not in args):
        print(f"Consumer assigned to topics -> {topic} with group.id: {group} on p: [{args.partition}] to fetch {args.num_messages} messages")
        tp = TopicPartition(topic, args.partition)

    #-> assign consumer to TopicPartition tuple
    c.assign([tp])

    messages = c.consume(args.num_messages)
    for msg in messages:
        key = avro_deserializer(msg.key(), SerializationContext(msg.topic(), MessageField.KEY))
        val = avro_deserializer(msg.value(), SerializationContext(msg.topic(), MessageField.VALUE))
        print(f"{Fore.YELLOW}-> Consumed msg from p@[o]: {msg.partition()}@[{msg.offset()}]{Fore.RESET}", end=" ")
        print(f"-> key: {Fore.CYAN}{key}{Fore.RESET}")
        print(f"val['data']: {Fore.LIGHTGREEN_EX}{json.dumps(val['data'], indent=2)}{Fore.RESET}")

    #-> and we are done... 
    c.close()

# main entry
if __name__ == '__main__':

    # => curl -u U4ZXASJVWQZQGEU7:SAozASmRuc0Pp6b8Wbr6BSjNRdiM9qcHt1d0EuRsN33Vwu95jAjTVnTDKwBdq19q https://psrc-4r0k9.westus2.azure.confluent.cloud/subjects/sit-eapi-cdp-ec_profile_il-value/versions/2
    avro_deserializer = get_avro_deserializer(config_dict)

    # instantiate consumer...
    c = Consumer(consumer_conf)

    #-> consume # messages from topic, partition and from offset if provided...exit when done
    if 'partition' in args:
        consume_topic_partition(args)
        exit()

    #-> Subscribe to topic...
    print(f"Subscribing to topics -> {[topic]} with group.id: {group}")
    c.subscribe([topic], on_assign=on_assign)

    #-> get # of partitions from the topic metadata...
    topic_partitions = len(list(c.list_topics(topic=topic).topics.values())[0].partitions)

    #-> Process messages...
    empty_consent_date: int = 0
    count: int = 0
    poll_count = 0
    start_time = time()
    try:
        while True:
            #-> start counting :)...
            poll_count += 1

            #-> poll for message...
            message: Message = c.poll(1.0)

            #-> damn we have been pulling for a while....sys.maxsize=9223372036854775807 
            if poll_count == sys.maxsize: poll_count = 1
            
            #-> no messages were pulled from topic...
            if message is None: 
                if poll_count%60 == 0: print(f'{datetime.utcnow().isoformat(sep=" ", timespec="seconds")} - Waiting...')
                continue

            if message.error():
                if message.error().code() == KafkaError._PARTITION_EOF: # End of partition event
                    print(f'-> {message.topic()} [{message.partition()}] reached end at offset {message.offset()}')
                    continue
                else:
                    raise KafkaException(message.error())

            #-> count received messages...
            count += 1 

            # -> message metadata details...i.e. partition, offset, timestemp, etc...
            p: int = message.partition()
            o: int = message.offset()
            ts_type, timestamp = message.timestamp()

            #-> set message type... 
            ts_type_str = 'TIMESTAMP_LOG_APPEND_TIME'
            if ts_type == 'TIMESTAMP_NOT_AVAILABLE':
                ts_type_str = 'TIMESTAMP_NOT_AVAILABLE'
            elif ts_type == 'TIMESTAMP_CREATE_TIME':
                ts_type_str = 'TIMESTAMP_CREATE_TIME'                

            # -> key and msg deserialization....
            key: Dict  = avro_deserializer(message.key(), SerializationContext(message.topic(), MessageField.KEY))
            msg: Dict = avro_deserializer(message.value(), SerializationContext(message.topic(), MessageField.VALUE))

            # ->
            if isinstance(avro_deserializer, AvroDeserializer):
                key_json: str = json.dumps(key, ensure_ascii=False)
                msg_json: str = json.dumps(msg['data'], ensure_ascii=False, indent=2)
            else:
                msg_json: str = json.dumps(json.loads(msg), ensure_ascii=False, indent=2)

            dt_iso: str = datetime.fromtimestamp(timestamp / 1000.0, tz=timezone.utc).isoformat()
            if not args.quiet:
                print(f"\n{Fore.LIGHTGREEN_EX}*=> Consumed msg from p@[o]: {p}@[{o}], type: {ts_type_str}, timestamp: {timestamp}, UTC: {dt_iso}{Style.RESET_ALL}")
                print(f'-> key: {key_json}')
                print(f'-> msg: \n{msg_json}')
            else:

                consent_create_date = msg['data']['CONSENTTRMSCREATEDATE']
                if not consent_create_date:
                    empty_consent_date += 1 
                
                # if count%1000 == 0:
                #     percent = '{:.2%}'.format(float(empty_consent_date)/count)
                #     print(f"-> empty_consent_date/total: {empty_consent_date}/{count} = {percent}")

            if args.num_messages != 0 and count >= args.num_messages:
                percent = '{:.2%}'.format(float(empty_consent_date)/count)
                print(f"-> Read {count} messages. # of messages with empty consent date: {empty_consent_date} -> {percent}")
                break
            
    except KeyboardInterrupt:
        pass
    except SerializerError as e:
        # Report malformed record, discard results, continue polling
        print(f"Message deserialization failed {e}")
    finally:
        #-> Close down consumer to commit final offsets.
        c.close()

    #-> we are done...
    print(f"-> Kafka Consumer commited offsets and left the group.")
