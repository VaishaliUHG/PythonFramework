
#!/usr/local/bin/python
#
# =============================================================================
#
# Produce messages to Confluent Cloud
# Using Confluent Python Client for Apache Kafka
#
# =============================================================================

from typing import List
from confluent_kafka import Producer, KafkaError
import sys
import json
import parser_lib
import random
from faker import Faker
from datetime import datetime, tzinfo, timezone
import pytz
import os

# rxsummary-ndc_filter_out'
# vscode_run_args = '--file consumer.dev.properties --topic dev-eapi-cdp-entlink_ids'
vscode_run_args = '--file consumer.sit.properties --topic sit-eapi-cdp-entlink_ids'
delivered_records = 0

next_src_id = ".next_srcid"
DEFAULT_SRCID = 425262000000
def get_src_id() -> int:
    src_id = DEFAULT_SRCID
    if os.path.isfile(next_src_id):
        with open(next_src_id, "r") as fh:
            src_id = int(fh.read())
    return src_id

# Optional per-message on_delivery handler (triggered by poll() or flush())
# when a message has been successfully delivered or permanently failed delivery (after retries).
def acked(err, msg):
    global delivered_records
    """
    Delivery report handler called on successful or failed delivery of message
    """
    if err is not None:
        print("Failed to deliver message: {}".format(err))
    else:
        delivered_records += 1
        # print(
        #     f"Produced record to topic {msg.topic()} partition [{msg.partition()}] @ offset {msg.offset()} [msg] -> {json.dumps(json.loads(msg.value()))}")


if __name__ == '__main__':
    fake = Faker()

    # Read arguments and configurations and initialize
    if len(sys.argv) == 1:  # fix the glitch with vscode run vs debug
        args = parser_lib.parse_args(vscode_run_args)
        if not args.quiet:
            print(
                f"Using module {sys.argv[0].split('/')[-1]} arguments: {vscode_run_args}")
    else:
        args = parser_lib.parse_args()
    config_file = args.config_file
    conf = parser_lib.read_cc_config(config_file)

    #-> set topic...
    topic = args.topic

    # Create Producer instance
    producer_conf = parser_lib.pop_schema_registry_params_from_config(conf)
    print(f"producer_conf: \n{json.dumps(producer_conf, indent=4)}\n")
    producer = Producer(producer_conf)

    evtTemplate: str = '{"sourceCode": "", "sourceId": "", "eid": ""}'
    val = json.loads(evtTemplate)

    src_id_: int = get_src_id()
    for i in range(1000):
 
        val['sourceCode'] = random.choice(['LR', 'EC', 'LR', 'IC', 'LR'])
        val['sourceId'] = str(src_id_)
        val['eid'] = "2" + str(src_id_) 

        #-> key and payload
        key: str = val['sourceCode'] + str(src_id_)
        msg: str = json.dumps(val)

        # -> pretty print event... 
        print(f"[{i}] -> key: {key}, msg: {json.dumps(val)}")

        #-> produce to kafka topic...
        producer.produce(topic, key=key, value=msg, on_delivery=acked)
        # p.poll() serves delivery reports (on_delivery) from previous produce() calls.
        producer.poll(0)

        src_id_ += 1
 
    #-> flush...flush...flush
    producer.flush()

    #-> save source id... 
    with open(next_src_id, "w") as fh:
        fh.write(str(src_id_))

    print("{} messages were produced to topic {}!".format(delivered_records, topic))
