#!/usr/local/bin/python
# /usr/local/bin/python
# /usr/bin/python3

# =============================================================================
#
# Consume messages from Confluent Cloud
# Using Confluent Python Client for Apache Kafka
# Reads Avro data, integration with Confluent Cloud Schema Registry
#
# =============================================================================

# from avro.schema import DEBUG_VERBOSE
from typing import Dict, List
import sys
import uuid
import socket
from datetime import datetime, timezone
import logging
from time import time
import json
import pytz

from confluent_kafka import OFFSET_INVALID
# from confluent_kafka import OFFSET_BEGINNING
from confluent_kafka import Consumer, Message, TopicPartition
from confluent_kafka import DeserializingConsumer
from confluent_kafka.admin import ClusterMetadata, BrokerMetadata, TopicMetadata, PartitionMetadata
from confluent_kafka.serialization import Deserializer, StringDeserializer
#, SerializationContext, MessageField

from confluent_kafka.avro.serializer import SerializerError
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.error import SchemaRegistryError
from confluent_kafka.schema_registry.avro import AvroDeserializer
# from confluent_kafka.schema_registry.schema_registry_client import RegisteredSchema

from colorama import Fore, Back, Style
import parser_lib


logging.basicConfig(level=logging.ERROR)
# log = logging.getLogger(__name__)

vscode_run_args = '--file consumer.sit.properties --group sit_grp_id.100 --messages 235000 --topic sit-eapi-cdp-lr_optin_il --quiet' # --verbose'

def get_deserializer(subject: str, conf: dict) -> Deserializer:
    """
    checks if schema exists: if schema exists return AvroDeserializer else return StringDeserializer

    Args:
        subject (str): Subject refers to either a “<topic>-key” or “<topic>-value” depending on whether you are lookig for the key schema or the value schema
    """

    # get schema kind from subject, i.e. key || value
    kind = subject.split('-')[-1]

    # set default Deserializer
    deserializer = StringDeserializer(codec='utf_8')

    # schema registry configuration...
    schema_registry_conf = {
        'url': conf['schema.registry.url'],
        'basic.auth.user.info': conf['schema.registry.basic.auth.user.info']
    }
    schema_registry_client: SchemaRegistryClient = SchemaRegistryClient(schema_registry_conf)

    # check if schema is in SchemaRegistry otherwise we default to StringDeserializer
    try:
        schema = schema_registry_client.get_latest_version(subject)
        deserializer = AvroDeserializer(schema_registry_client, schema.schema.schema_str)

        
        if args.verbose:
            print(f"{Fore.GREEN}Subject: {subject}{Style.RESET_ALL} -> {Fore.CYAN}versioins: {schema_registry_client.get_versions(subject)}{Style.RESET_ALL}")
            print(f"Using AvroDeserializer with {kind}-schema: \n{json.dumps(json.loads(schema.schema.schema_str), indent=4)}")
        elif not args.quiet:
            print(f"{Fore.GREEN}Using AvroDeserializer with {kind}-schema: subject={schema.subject}, id={schema.schema_id}, version={schema.version}.{Style.RESET_ALL}")
    except TypeError:
        if not args.quiet:
            print(f"{Fore.CYAN}Using AvroDeserializer, {kind}-schema: subject={subject} not in SchemaRegistry.{Style.RESET_ALL}")
    except SchemaRegistryError:
        if not args.quiet:
            print(f"{Fore.CYAN}Using AvroDeserializer, {kind}-schema: subject={subject} not in SchemaRegistry.{Style.RESET_ALL}")

    return deserializer


def on_assign(consumer, partitions: List[TopicPartition]) -> None:
    """ handling of offsets on completion of a successful partition re-assignment """

    # # Query committed offsets for this group and the given partitions
    # committed: List[TopicPartition] = None
    # committed = consumer.committed(partitions, timeout=10.0)

    # # for all commited partitions...
    # for _p in committed:
    #     # Get the partition low, high watermarks and "group.id" partition offset.
    #     (lo, hi) = consumer.get_watermark_offsets(_p, timeout=10, cached=False)
    #     offset = '-' if _p.offset == OFFSET_INVALID else _p.offset
    #     lag = "no hwmark" if hi < 0 else ((hi - lo) if _p.offset < 0 else (hi - _p.offset))
    #     if not args.quiet:
    #         print(f"{Fore.LIGHTYELLOW_EX}Partition: {Fore.MAGENTA}{_p.partition}@[offset: {offset: <10}, lo: {lo: <10}, hi: {hi: <10}, lag: {lag: <10}]{Style.RESET_ALL}")


def consume_topic_partition(topic: str, partition: int, offset: int, num_messages: int) -> None:
    if topic and partition and offset:
        tp = TopicPartition(topic, partition, offset)
        consumerClient.assign([tp])

        messages = consumerClient.consume(num_messages)
        for _msg in messages:
            _key = key_deserializer.__call__(_msg.key(), None)
            _val = val_deserializer.__call__(_msg.value(), None)
            print(f"p@[o]: {_msg.partition()}@[{_msg.offset()}] ", end=" ")
            print(f"key: {_key}")
            print(f"value: {json.dumps(_val, indent=4)}")

        consumerClient.close()


# main entry
if __name__ == '__main__':

    # Read arguments and configurations and initialize
    if len(sys.argv) == 1:  # fix the glitch with vscode run vs debug
        args = parser_lib.parse_args(vscode_run_args)
        if not args.quiet:
            print(f"Using module {sys.argv[0].split('/')[-1]} arguments: {vscode_run_args}")
    else:
        args = parser_lib.parse_args()
    config_file = args.config_file
    config_dict = parser_lib.read_cc_config(config_file)

    if args.verbose:
        print(
            f"{Fore.BLUE}Kafka Consumer Cofiguration: {Style.RESET_ALL}\n{json.dumps(config_dict, indent=4)}")

    # -> we need a topic
    topic_name = args.topic

    # => curl -u U4ZXASJVWQZQGEU7:SAozASmRuc0Pp6b8Wbr6BSjNRdiM9qcHt1d0EuRsN33Vwu95jAjTVnTDKwBdq19q https://psrc-4r0k9.westus2.azure.confluent.cloud/subjects/sit-eapi-cdp-ec_profile_il-value/versions/2
    key_deserializer = get_deserializer(topic_name + "-key", config_dict)
    val_deserializer = get_deserializer(topic_name + "-value", config_dict)

    # for full list of configurations, see: https://docs.confluent.io/current/clients/confluent-kafka-python/#deserializingconsumer
    group: str = args.group if args.group is not None else str(uuid.uuid1())
    consumer_conf = {
        'bootstrap.servers': config_dict['bootstrap.servers'],
        'sasl.mechanism': config_dict['sasl.mechanisms'],
        'security.protocol': config_dict['security.protocol'],
        'sasl.username': config_dict['sasl.username'],
        'sasl.password': config_dict['sasl.password'],
        # 'key.deserializer': key_deserializer,
        # 'value.deserializer': val_deserializer,
        # 'debug': 'all', #generic, broker, topic, metadata, feature, queue, msg, protocol, cgrp, security, fetch, interceptor, plugin, consumer, admin, eos, mock, all
        'group.id': group,
        'enable.auto.commit': False,
        'api.version.request': True,
        'client.id': socket.gethostname(),
        # 'auto.offset.reset': 'latest'
        'auto.offset.reset': 'earliest'
    }

    # instantiate consumer...
    consumerClient = Consumer(consumer_conf)

    # consume # messages from topic, partition and offset...exit when done
    # if args.topic and args.partition and args.offset:
    #     consume_topic_partition(args.topic, args.partition, args.offset, args.num_messages)
    #     exit()

    # consumer.assign(partitions)
    # for i in range(100):
    #     message = consumer.consume()[0]
    #     key = key_deserializer.__call__(message.key(), None)
    #     val = val_deserializer.__call__(message.value(), None)
    #     print(f"p@[o]: {message.partition()}@[{message.offset()}] ", end=" ")
    #     print(f"key: {key}")

    # consumer.close()
    # exit()

    # Subscribe to topic
    if not args.quiet:
        print(f"Subscribing to {Fore.LIGHTYELLOW_EX}topics -> {topic_name}, group.id: {group}{Style.RESET_ALL}")
    consumerClient.subscribe([topic_name], on_assign=on_assign)

    # Process messages
    empty_consent_date: int = 0
    count: int = 0
    events: int = 0
    start_time = time()
    timeout = 1.0
    while True:
        try:
            message: Message = consumerClient.poll(timeout)

            if message is None:
                # No message available within timeout. Initial message consumption may take up to `session.timeout.ms` for the consumer group to rebalance and start consuming
                continue
            elif message.error():
                print(f"error: {message.error()}")
            else:
                count += 1  # -> count for received messages...
                events += 1

                # -> message metadata details...i.e. partition, offset, timestemp, etc...
                p:   int = message.partition()
                o:   int = message.offset()
                ts_type, timestamp = message.timestamp()

                if ts_type == 'TIMESTAMP_NOT_AVAILABLE':
                    ts_type_str = 'TIMESTAMP_NOT_AVAILABLE'
                elif ts_type == 'TIMESTAMP_CREATE_TIME':
                    ts_type_str = 'TIMESTAMP_CREATE_TIME'
                else: 
                    ts_type_str = 'TIMESTAMP_LOG_APPEND_TIME'

                # -> key and msg deserialization....
                key: str = key_deserializer.__call__(message.key(), None)
                msg: Dict = val_deserializer.__call__(message.value(), None)

                # ->
                if isinstance(val_deserializer, AvroDeserializer):
                    msg_json: str = json.dumps(msg['data'], ensure_ascii=False, indent=2)
                    # print(f"{str(msg_json)}")
                else:
                    msg_json: str = json.dumps(json.loads(msg), ensure_ascii=False, indent=4)

                dt_iso: str = datetime.fromtimestamp(timestamp / 1000.0, tz=timezone.utc).isoformat()
                if not args.quiet:
                    # print(f"\n{Fore.LIGHTBLUE_EX}*=> Consumed msg from partitio@[offset]: {p}@[{o}], type: {ts_type_str}, timestamp: {timestamp}, UTC: {dt_iso}{Style.RESET_ALL}\n{msg_json}")
                    print(f"\n{Fore.LIGHTBLUE_EX}*=> Consumed msg from partitio@[offset]: {p}@[{o}], type: {ts_type_str}, timestamp: {timestamp}, UTC: {dt_iso}{Style.RESET_ALL}\n{msg['data']}")
                    # pass
                else:

                    consent_create_date = msg['data']['CONSENTTRMSCREATEDATE']
                    if not consent_create_date:
                        empty_consent_date += 1 
                        # print(f"{msg_json}")
                    
                    if count%1000 == 0:
                        percent = '{:.2%}'.format(float(empty_consent_date)/count)
                        print(f"-> empty_consent_date/total: {empty_consent_date}/{count} = {percent}")

                if args.num_messages != 0 and count >= args.num_messages:
                    percent = '{:.2%}'.format(float(empty_consent_date)/count)
                    print(f"-> Read {count} messages. # of messages with empty consent date: {empty_consent_date} -> {percent}")
                    break
        except KeyboardInterrupt:
            break
        except SerializerError as e:
            # Report malformed record, discard results, continue polling
            print(f"Message deserialization failed {e}")

    # Leave group and commit final offsets
    consumerClient.close()

    #-> we are done...
    print(f"-> Kafka Consumer commited offsets and left the group.")
