#!/usr/local/bin/python
# /usr/bin/python3

# =============================================================================
#
# Consume messages from Confluent Cloud
# Using Confluent Python Client for Apache Kafka
# Reads Avro data, integration with Confluent Cloud Schema Registry
#
# =============================================================================

# from avro.schema import DEBUG_VERBOSE
import time
from typing import Any, AnyStr, Dict, Iterable, List, Tuple
import sys
import argparse
import uuid
import json
import logging
# import datetime
from colorama.ansi import Fore, Style
from datetime import datetime, tzinfo, timezone
import pytz

from confluent_kafka import Consumer, TopicPartition
from confluent_kafka import Message, TIMESTAMP_NOT_AVAILABLE, TIMESTAMP_CREATE_TIME, TIMESTAMP_LOG_APPEND_TIME
from confluent_kafka import OFFSET_INVALID, OFFSET_BEGINNING
from confluent_kafka import KafkaException
from confluent_kafka.admin import AdminClient, ClusterMetadata, BrokerMetadata, ConfigResource, ConfigSource, GroupMember, GroupMetadata, TopicMetadata, PartitionMetadata
from confluent_kafka.admin import RESOURCE_BROKER, RESOURCE_TOPIC, RESOURCE_GROUP
import concurrent.futures
import socket

logging.basicConfig(level=logging.ERROR)
# log = logging.getLogger(__name__)

vscode_run_args = '--file consumer.prd.properties --group vacadmin-amc_grp_cdc_prod_2021-04-06_001 --filter prod-eapi-rxsummary-ndc_filter_out' #--verbose
# vscode_run_args = '--file consumer.prd.properties --group vacadmin-amcemail_grp_cdc_prod_2021-05-04_001 --filter prod-eapi-rxsummary-ndc_filter_out'
# vscode_run_args = '--file consumer.prd.properties --group mmcamem_grp_cdc_prod_2021-04-12-001 --filter prod-eapi-cdp-lr_profile --verbose'
# vscode_run_args = '--file consumer.prd.properties --group icprofile_phone_grp_prod_2021-04-12-001 --filter prod-eapi-cdp-ic_profile_phone --verbose'
# vscode_run_args = '--file consumer.prd.properties --group memhead_grp_cdc_prod_2021-04-13-001 --filter prod-eapi-cdp-cdi_mpi_memhead --verbose'
# vscode_run_args = '--file consumer.prd.properties --group entlink_grp_cdc_prod_2021-04-13-001 --filter prod-eapi-cdp-cdi_mpi_entlink_id --verbose'
# vscode_run_args = '--file consumer.prd.properties --group icprofile_grp_prod_2021-04-12-001 --filter prod-eapi-cdp-ic_profile --verbose'
# vscode_run_args = '--file consumer.prd.properties --group ecommprofile_grp_il_prod_2020-11-10-001 --filter prod-eapi-customer-ild-cdi_ecom_profile_v --verbose'
# vscode_run_args = '--file consumer.prd.properties --group ecommprofile_grp_cdc_prod_2020-11-10-001 --filter prod-eapi-customer-ecomm_profile_change --verbose'
# vscode_run_args = '--file consumer.prod.properties --group g.id.42 --filter prod-eapi-cdp-lr_profile'
# vscode_run_args = '--file consumer.prod.properties --topics prod-eapi-cdp-cdi_mpi_entlink_id_purged_il prod-eapi-cdp-cdi_mpi_memhead_purged_il prod-eapi-cdp-cdi_mpi_entlink_id_il prod-eapi-cdp-lr_profile_purged_il prod-eapi-cdp-ic_profile_phone_il prod-eapi-cdp-cdi_mpi_memhead_il prod-eapi-cdp-ic_profile_il prod-eapi-cdp-lr_profile_il'

# vscode_run_args = '--file consumer.prod.properties --topics prod-eapi-rxsummary-ndc_filter_out'
# vscode_run_args = '--file consumer.prod.properties --group g.id.52 --filter prod-eapi-cdp-cdi_mpi_entlink_id_purged_il --verbose'
# vscode_run_args = '--file consumer.prod.properties --group g.id.52 --filter prod-eapi-cdp-lr_profile_purged_il --verbose'

#-> verbosity
verbose: bool = False
display: bool = True
sum_lst: int = 0

def parse_args(vscode_run_args: str = None):
    """Parse command line arguments"""

    global verbose
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--file'         , help="path to configuration file", dest="config_file", metavar='file', required=True)
    parser.add_argument('-t', '--topics'       , help="kafka topics", dest="topics", metavar='topics', type=str, nargs='+', default=None, required=False)
    parser.add_argument('-g', '--group'        , help="set group.id", dest="group", metavar='group', type=str, required=False)
    parser.add_argument('--filter'             , help="topic filter", dest='filter', metavar='substr', type=str, default=None, required=False)
    parser.add_argument('-v', '--verbose'      , help="enable verbose mode", action='store_true',  required=False)

    if vscode_run_args:
        args = parser.parse_args(vscode_run_args.split())
    else:
        args = parser.parse_args()
    
    if args.verbose:
        print(f"{args}")
        verbose = True

    return args

def read_config(config_file):
    """Read Confluent Cloud configuration for librdkafka clients"""

    conf: Dict[str, str] = {}
    with open(config_file,"r") as fh:
        for line in fh:
            line = line.strip()
            if len(line) != 0 and line[0] != "#":
                parameter, value = line.strip().split('=', 1)
                conf[parameter] = value.strip()

    return conf

def init() -> Tuple[Dict[str,str], argparse.Namespace, str, List[str]]:
    """ Parse arguments and initialize configurations """

    if len(sys.argv) == 1: # fix the glitch with vscode run vs debug 
        global vscode_run_args
        print(f"Using module {sys.argv[0].split('/')[-1]} arguments: {vscode_run_args}")
        args = parse_args(vscode_run_args)
    else:
        args = parse_args()
 
    # topics list
    topics: List[str] = args.topics
    if args.verbose:
        print(f"Topics -> {topics}")

    _conf = read_config(args.config_file)
    if args.verbose:
        print(f"Kafka properties file: {args.config_file}\n{json.dumps(_conf, indent=4)}")

    try:
        _environement: str = _conf['kafka.environement']
    except KeyError as e:
        print(f"KeyError: missing required property '{e.args[0]}', i.e. kafka.environement=<env>")
        exit(1)
    else:
        kafka_environment = _environement.upper()
        
    # for full list of configurations, see: https://docs.confluent.io/current/clients/confluent-kafka-python/#deserializingconsumer
    consumer_config = {
        'bootstrap.servers': _conf['bootstrap.servers'],
        'sasl.mechanism': _conf['sasl.mechanisms'],
        'security.protocol': _conf['security.protocol'],
        'sasl.username': _conf['sasl.username'],
        'sasl.password': _conf['sasl.password'],
        # 'debug': 'protocol', #generic, broker, topic, metadata, feature, queue, msg, protocol, cgrp, security, fetch, interceptor, plugin, consumer, admin, eos, mock, all
        'api.version.request': True,
        'enable.auto.commit': False,
        'client.id': socket.gethostname(),
        'group.id': args.group if args.group is not None else str(uuid.uuid1())
    }
    if args.verbose:
        print(f"Kafka Consumer Cofiguration: \n{json.dumps(consumer_config, indent=4)}")

    return consumer_config, args, kafka_environment, topics

def timestamp_topic_partition_offset(topic: str, partition: int, offset: int) -> Tuple[int,str]:
    """ 
    Retrieves type and timestamp from message for a given [topic, partition, offset]
    
    The timestamp type is one of:
        TIMESTAMP_NOT_AVAILABLE - Timestamps not supported by broker.
        TIMESTAMP_CREATE_TIME - Message creation time (or source / producer time).
        TIMESTAMP_LOG_APPEND_TIME - Broker receive time.
        The returned timestamp should be ignored if the timestamp type is TIMESTAMP_NOT_AVAILABLE.

    The timestamp is the number of milliseconds since the epoch (UTC).
    """
    
    # consume  message
    c.assign([TopicPartition(topic, partition, offset)])
    msg = c.consume(num_messages=1,timeout=30)
    c.unassign()

    # read timestamp...
    if (len(msg) == 0):
        print(f'\nn{Fore.RED}timestamp_topic_partition_offset -> [{topic}] -> p@[o]: {partition}@[{offset}] not able to consume msg...eject...eject...eject{Style.RESET_ALL}')
        exit()
    else:
        timestamp_type, timestamp = msg[0].timestamp()

    if timestamp_type == TIMESTAMP_NOT_AVAILABLE:
        dt_iso: str = 'TIMESTAMP_NOT_AVAILABLE'
    else:
        dt_iso: str = datetime.fromtimestamp(timestamp / 1000.0, tz=pytz.timezone('US/Central')).strftime("%Y-%m-%d %H:%M:%S") #.isoformat()
        # dt_iso: str = datetime.fromtimestamp(timestamp / 1000.0, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S") #.isoformat()

    return timestamp, dt_iso    

def cluster_metadata(c: Consumer, a: AdminClient, filter_pattern: str = '') -> None:
    """ """
    global verbose
    md: ClusterMetadata = c.list_topics()

    global display
    if verbose and display:
        display = False
        print(f"\n*=======> {kafka_environement} Cluster Metadata <=======*\n")
        print(f"  Cluster ID: {md.cluster_id}")
        print(f"  Controller Broker ID: {md.controller_id}")
        # print(f"  Original   Broker ID: {md.orig_broker_id}")
        print(f"  Original Broker Name: {md.orig_broker_name}\n")
        
        # list cluster brokers... 
        b: BrokerMetadata
        for b in md.brokers.values():
            if b.id == md.controller_id:
                print(f"  Broker({b.id}): {b.host}:{b.port} (controler)")
            else:
                print(f"  Broker({b.id}): {b.host}:{b.port}")

        print(f"\n*=======> {kafka_environement} Cluster Metadata <=======*\n")

    # get topics ...
    topics: List[TopicMetadata] = list(filter(lambda t : filter_pattern in t.topic, md.topics.values()))

    #-> list topic metadata
    tm: TopicMetadata = None
    for tm in topics:
        if md.topics[tm.topic].error is not None:
            raise KafkaException(md.topics[tm.topic].error)

        #-> exact match 
        if str(tm.topic) != filter_pattern:
            continue

        #-> Construct TopicPartition list of partitions to query
        partitions = [TopicPartition(tm.topic, p) for p in tm.partitions]

        #-> Query committed offsets for this group and the given partitions
        committed: List[TopicPartition] = c.committed(partitions, timeout=20)

        #-> get groups
        groups: List[GroupMetadata] = a.list_groups(group,timeout=30)

        if len(groups) == 1:
            topic_group: str = 'TOPIC: ' + tm.topic + ', partitions: ' + str(len(tm.partitions)) + ', group.id: "' + group + '", members: ' + str(len(groups[0].members))
        else:
            topic_group: str = 'TOPIC: ' + tm.topic + ', partitions: ' + str(len(tm.partitions)) + ', group.id: "' + group + '" does not exist.'

        print(f"{Fore.LIGHTGREEN_EX}*=>>> {topic_group}{Style.RESET_ALL}")
        if verbose:
            if len(tm.partitions) < 100:
                print(f"{'P[##]': <7}{'CURRENT-OFFSET': <16}{'LO-WATERMARK': <14}{'HI-WATERMARK': <14}{'LAG': <10}{'LO-TIMESTAMP': <22}{'CURRENT-TIMESTAMP': <22}{'HI-TIMESTAMP': <22}{''}")
            else:
                print(f"{'P[###]': <7}{'CURRENT-OFFSET': <16}{'LO-WATERMARK': <14}{'HI-WATERMARK': <14}{'LAG': <10}{''}")

        dt_lo: str = '-'
        dt_hi: str = '-'
        sum_lag: int = 0 # sum -> lag from each partition 
        sum_evt: int = 0 # sum -> total events retained on kafka topic
        pm: PartitionMetadata = None
        for pm in tm.partitions.values(): #PartitionMetadata

            #-> get committed TopicPartition metadata
            tp: TopicPartition = committed[pm.id]

            # Get the partitions low and high watermark offsets.
            (lo, hi) = c.get_watermark_offsets(tp, timeout=15, cached=False)
            offset = '-' if tp.offset == OFFSET_INVALID else tp.offset
            lag = "no hwmark" if hi < 0 else ( (hi - lo) if tp.offset < 0 else (hi - tp.offset) )
        
            sum_lag += lag # sum -> lag from each partition
            sum_evt += (hi - lo) #-> sum -> events retained on partition

            #-> need to understand why for high # of partitions high watermark delta needs to be 2???  
            if len(tm.partitions) >= 100:
                hwd = 2
            else:
                hwd = 1

            #-> get timestamp from lo and hi watermark
            if verbose:
                if (lo != hi or hi>0) and len(tm.partitions) < 100:
                    # ts_lo, dt_lo = timestamp_topic_partition_offset(tm.topic, pm.id, tp.offset)
                    # ts_hi, dt_hi = timestamp_topic_partition_offset(tm.topic, pm.id, hi-hwd)  
                    ts_lo, dt_lo = timestamp_topic_partition_offset(tm.topic, pm.id, lo)
                    ts_of, dt_of = timestamp_topic_partition_offset(tm.topic, pm.id, offset)
                    ts_hi, dt_hi = timestamp_topic_partition_offset(tm.topic, pm.id, offset if offset == hi else hi-hwd)               
                    # print(f"P[{pm.id: >2}]{offset: >16}{lo: >14}{hi: >15}   {lag: <10}    {ts_lo}:{dt_lo}   {ts_hi}:{dt_hi}") #  leader={pm.leader}, replicas={pm.replicas}, isrs={pm.isrs}", end=", ")
                    print(f"P[{pm.id: >2}]{offset: >16}{lo: >14}{hi: >14}  {lag: <8}  {dt_lo}   {dt_of}   {dt_hi} | -> leader: {pm.leader: >2} | -> replicas: {str(pm.replicas): >11} | -> isrs: {str(pm.isrs): >11}{''}")
                else:
                    print(f"P[{pm.id: >3}]{offset: >15}{lo: >14}{hi: >14}  {lag: <8} | -> leader: {pm.leader: >2} | -> replicas: {str(pm.replicas): >11} | -> isrs: {str(pm.isrs): >11}{''}") 

        # else:
        global sum_lst
        sum_dlt = sum_evt - sum_lst
        sum_lst = sum_evt
        now_iso: str = datetime.now(tz=pytz.timezone('US/Central')).strftime("%Y-%m-%d %H:%M:%S")
        if sum_lag > 0 and len(tm.partitions) >= 100:
            sum_lag -= len(tm.partitions) # for some reason if # of partitions > 100 we always have lag 1 
            sum_dlt -= len(tm.partitions) 
            
        print(f"{Fore.WHITE}[{now_iso}] {Fore.LIGHTCYAN_EX}Total events -> {sum_evt:,d} {Fore.LIGHTYELLOW_EX}Delta -> {sum_dlt:,d} {Fore.LIGHTRED_EX}Processig Lag -> {sum_lag:,d}{Style.RESET_ALL}\n")

def topic_lag(c: Consumer, filter_pattern: str = '') -> None:
    """ """

    #-> get cluster metadata
    md: ClusterMetadata = c.list_topics()

    # get topics ...
    topics: List[TopicMetadata] = list(filter(lambda t : filter_pattern in t.topic, md.topics.values()))

    tm: TopicMetadata = None
    for tm in topics:
        if md.topics[tm.topic].error is not None:
            raise KafkaException(md.topics[tm.topic].error)

        #-> remove DLT topics
        if str(tm.topic).endswith('DLT'):
            continue

        # Construct TopicPartition list of partitions to query
        partitions = [TopicPartition(tm.topic, p) for p in tm.partitions]

        # Query committed offsets for this group and the given partitions
        committed: List[TopicPartition] = c.committed(partitions, timeout=20)
        
        # sum -> lag from each partition 
        pm: PartitionMetadata = None
        total_lag: int = 0
        total_cnt: int = 0
        for pm in tm.partitions.values(): #PartitionMetadata

            tp: TopicPartition = committed[pm.id]
            # Get the partitions low and high watermark offsets.
            (lo, hi) = c.get_watermark_offsets(tp, timeout=10, cached=False)
            # offset = '-' if tp.offset == OFFSET_INVALID else tp.offset
            lag = "no hwmark" if hi < 0 else ( (hi - lo) if tp.offset < 0 else (hi - tp.offset) )
            
            # if lo != hi or hi>0:
            #     ts_lo, dt_lo = timestamp_topic_partition_offset(tm.topic, pm.id, lo)
            #     ts_hi, dt_hi = timestamp_topic_partition_offset(tm.topic, pm.id, hi-1)                
            #     print(f"P[{pm.id: >2}]{offset: >16}{lo: >14}{hi: >15}   {lag: <10}    {ts_lo}:{dt_lo}   {ts_hi}:{dt_hi}") #                           leader={pm.leader}, replicas={pm.replicas}, isrs={pm.isrs}", end=", ")
            # else:
                # print(f"P[{pm.id: >3}]{offset: >16}{lo: >14}{hi: >15}   {lag: <10}") 

            total_lag += lag
            total_cnt += (hi - lo)

        # print(f"\n*=>>> {topic_group}")
        now_iso: str = datetime.now(tz=pytz.timezone('US/Central')).strftime("%Y-%m-%d %H:%M:%S") #.isoformat(sep=' ', timespec='seconds')
        print(f"{Style.NORMAL}{Fore.GREEN}{tm.topic}{Fore.WHITE} [{now_iso}] {Fore.BLUE}{total_cnt:,d} {Fore.YELLOW}Processig Lag -> {Style.BRIGHT}{Fore.RED}{total_lag}{Style.RESET_ALL}")
            
    # print(f"\n*=======> {kafka_environement} Cluster Metadata <=======*")

def topics_lag(c: Consumer, topics: List[str]) -> None:
    """ """

    #-> get cluster metadata
    md: ClusterMetadata = c.list_topics()

    # get topics ...
    # my_topics: List[TopicMetadata] = list(filter(lambda t : filter_pattern in t.topic, md.topics.values()))
    topics: List[TopicMetadata] = list(filter(lambda t : t.topic in topics, md.topics.values()))

    tm: TopicMetadata = None
    for tm in topics:
        if md.topics[tm.topic].error is not None:
            raise KafkaException(md.topics[tm.topic].error)

        # Construct TopicPartition list of partitions to query
        partitions = [TopicPartition(tm.topic, p) for p in tm.partitions]

        # Query committed offsets for this group and the given partitions
        committed: List[TopicPartition] = c.committed(partitions, timeout=20)
        
        # sum -> lag from each partition 
        pm: PartitionMetadata = None
        total_lag: int = 0
        for pm in tm.partitions.values(): #PartitionMetadata

            tp: TopicPartition = committed[pm.id]
            # Get the partitions low and high watermark offsets.
            (lo, hi) = c.get_watermark_offsets(tp, timeout=10, cached=False)
            # offset = '-' if tp.offset == OFFSET_INVALID else tp.offset
            lag = "no hwmark" if hi < 0 else ( (hi - lo) if tp.offset < 0 else (hi - tp.offset) )
            
            total_lag += lag

        # print(f"\n*=>>> {topic_group}")
        now_iso: str = datetime.now(tz=pytz.timezone('US/Central')).strftime("%Y-%m-%d %H:%M:%S") #.isoformat(sep=' ', timespec='seconds')
        # print(f"{Style.NORMAL}{Fore.GREEN}{tm.topic}{Fore.BLUE}[{now_iso}] {Fore.YELLOW}Processig Lag -> {Style.BRIGHT}{Fore.RED}{total_lag}{Style.RESET_ALL}")
        print(f"{Style.BRIGHT}{Fore.GREEN}[{now_iso}] {Fore.LIGHTMAGENTA_EX}[{Fore.BLUE}{tm.topic: <42}{Fore.LIGHTMAGENTA_EX}] {Fore.YELLOW}Processig Lag -> {Style.BRIGHT}{Fore.RED}{total_lag:,}{Style.RESET_ALL}")

    # print(f"\n*=======> {kafka_environement} Cluster Metadata <=======*")

def topic_metadata(topics: List[str] = None) -> None:
    """ """
    metadata: ClusterMetadata = None
    if topics is None: #list all topics
        metadata = c.list_topics()
        topics = list(map(lambda t : t.topic, metadata.topics.values()))
    else:
        metadata = c.list_topics(topics[0])

    print(f"\n*=======> Cluster Metadata <=======*\n")
    print(f"  Cluster ID: {metadata.cluster_id}")
    print(f"  Controller Broker ID: {metadata.controller_id}\n")

    # list cluster brokers...
    bk: BrokerMetadata
    for bk in metadata.brokers.values():
        print(f"  Broker({bk.id}): {bk.host}:{bk.port}")

    print(f"\n*=======> Cluster Metadata <=======*")
    
    # 
    for topic in topics:
        metadata = c.list_topics(topic, timeout=10)
        if metadata.topics[topic].error is not None:
            raise KafkaException(metadata.topics[topic].error)
    
        print(f"\n*==>>> {metadata.topics[topic]}[0:{len(metadata.topics[topic].partitions)-1}]:")

        # Construct TopicPartition list of partitions to query
        partitions = [TopicPartition(topic, p) for p in metadata.topics[topic].partitions]

        # Query committed offsets for this group and the given partitions
        committed: List[TopicPartition] = None
        committed = c.committed(partitions, timeout=10)
        # print(f"{committed}")
    
        partition: TopicPartition = None
        for partition in committed:
            # Get the partitions low and high watermark offsets.
            (lo, hi) = c.get_watermark_offsets(partition, timeout=10, cached=False)

            if partition.offset == OFFSET_INVALID:
                offset = "-"
            else:
                offset = "%d" % (partition.offset)

            if hi < 0:
                lag = "no hwmark"  # Unlikely
            elif partition.offset < 0:
                # No committed offset, show total message count as lag.
                # The actual message count may be lower due to compaction and record deletions.
                lag = "%d" % (hi - lo)
            else:
                lag = "%d" % (hi - partition.offset)

            print("%-30s  %9s  %9s" % (
                "{} [{}]".format(partition.topic, partition.partition), offset, lag))       

        # print(f"\n*==>>> {metadata.topics[topic]}[{len(metadata.topics[topic].partitions)}]:")
        # p: PartitionMetadata
        # for p in metadata.topics[topic].partitions.values():
        #     print(f"   [{p.id}]: leader={p.leader}, replicas={p.replicas}, isrs={p.isrs} ")

def print_config(config, depth):
    print('%40s = %-50s  [%s,is:read-only=%r,default=%r,sensitive=%r,synonym=%r,synonyms=%s]' %
          ((' ' * depth) + config.name, config.value, ConfigSource(config.source),
           config.is_read_only, config.is_default,
           config.is_sensitive, config.is_synonym,
           ["%s:%s" % (x.name, ConfigSource(x.source))
            for x in iter(config.synonyms.values())]))

def describe_configs(a, args):
    """ describe configs """

    # resources = [ConfigResource(restype, resname) for
    #              restype, resname in zip(args[0::2], args[1::2])]

    resources = [ConfigResource(RESOURCE_TOPIC, "dev-eapi-cdi-il-mpi_memhead")]

    fs = a.describe_configs(resources)

    # Wait for operation to finish.
    for res, f in fs.items():
        try:
            configs = f.result()
            for config in iter(configs.values()):
                print_config(config, 1)

        except KafkaException as e:
            print("Failed to describe {}: {}".format(res, e))
        except Exception:
            raise

def list_metadata(a: AdminClient = None, what: str = 'all'):
    """ list topics, groups and cluster metadata """

    md = a.list_topics(timeout=10)
    print("Cluster {} metadata (response from broker {}):".format(md.cluster_id, md.orig_broker_name))

    if what in ("all", "brokers"):
        print(" {} brokers:".format(len(md.brokers)))
        for b in iter(md.brokers.values()):
            if b.id == md.controller_id:
                print("  {}  (controller)".format(b))
            else:
                print("  {}".format(b))

    if what in ("all", "topics"):
        print(" {} topics:".format(len(md.topics)))
        for t in md.topics.values():
            if t.error is not None:
                errstr = ": {}".format(t.error)
            else:
                errstr = ""

            print("  \"{}\" with {} partition(s){}".format(t, len(t.partitions), errstr))

            for p in iter(t.partitions.values()):
                if p.error is not None:
                    errstr = ": {}".format(p.error)
                else:
                    errstr = ""

                print("partition {} leader: {}, replicas: {},"
                      " isrs: {} errstr: {}".format(p.id, p.leader, p.replicas,
                                                    p.isrs, errstr))

    if what in ("all", "groups"):
        groups = a.list_groups(group,timeout=10)
        print(" {} consumer groups".format(len(groups)))
        g: GroupMetadata = None
        # g.members
        for g in groups:
            if g.error is not None:
                errstr = ": {}".format(g.error)
            else:
                errstr = ""

            print(" \"{}\" with {} member(s), protocol: {}, protocol_type: {}{}".format(
                  g, len(g.members), g.protocol, g.protocol_type, errstr))
                  
            m: GroupMember = None
            for m in g.members:
                print("id {} client_id: {} client_host: {}".format(m.id, m.client_id, m.client_host))    

# main entry 
if __name__ == '__main__':

    args: argparse.Namespace = None
    config, args, kafka_environement, topics = init()
    group:str = args.group

    # Kafka Consumer
    c = Consumer(config)

    # AdminClient
    config.pop('group.id')
    config.pop('enable.auto.commit')
    a = AdminClient(config)

    # list_metadata(a, 'groups')
    # exit()

    # list cluster metadata
    for i in range(60):
        cluster_metadata(c, a, args.filter)
        # topic_lag(c, args.filter)
        time.sleep(58)


# entlink_grp_il_prod_2021-04-10-001
# memhead_grp_il_prod_2021-04-10-001
# entlink_grp_purged_il_prod_2021-04-10-001
# memhead_grp_purged_il_prod_2021-04-10-001
# ecommprofile-il_prod_2020-11-10-001
# icprofile_grp_il_uat_2021-04-09-001
# lrprofilepurged_il_prod_2021-04-10-001
# icprofilemongo_il_prod_2021-04-10-001
# lrprofile_grp_il_prod_2021-04-10-001

    # get topic lag
    # if args.filter is not None:
    #     for i in range(60):
    #         topic_lag(c, args.filter)
    #         print("")
    #         time.sleep(59)
        # for i in range(60):
        #     topic_lag(c, 'prod-eapi-cdp-ic_profile_phone_il')
        #     print("")
        #     time.sleep(59)
    # else:
    #     for i in range(60):
    #         topics_lag(c, topics)
    #         print("")
    #         time.sleep(59)

    # list_metadata(a, 'topics')
    # describe_configs(a, args)
