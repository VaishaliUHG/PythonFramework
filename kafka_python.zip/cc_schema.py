#!/usr/bin/env python3.9

# =============================================================================
#
# Consume messages from Confluent Cloud
# Using Confluent Python Client for Apache Kafka
# Reads Avro data, integration with Confluent Cloud Schema Registry
#
# =============================================================================

from typing import Dict, List
import sys
import json
import re

from confluent_kafka import DeserializingConsumer
from confluent_kafka.admin import ClusterMetadata, BrokerMetadata, TopicMetadata, PartitionMetadata
from confluent_kafka.serialization import Deserializer, StringDeserializer
from confluent_kafka.avro.serializer import SerializerError
from confluent_kafka.schema_registry import SchemaRegistryClient, RegisteredSchema
from confluent_kafka.schema_registry.error import SchemaRegistryError
from confluent_kafka.schema_registry.avro import AvroDeserializer

from colorama import Fore, Back, Style
import parser_lib

# -> list schema for given topic
# vscode_run_args = '--file consumer.prd.properties --topic sit-eapi-cdp-lr_profile'
# -> if topic is not specified list all schema
vscode_run_args = '--file consumer.prd.properties'

def get_schema_subjects(conf: dict) -> None:
    """
    List all subjects registered with the Schema Registry

    See Also:
        `GET subjects API Reference <https://docs.confluent.io/current/schema-registry/develop/api.html#get--subjects-(string-%20subject)-versions>`_
    """

    # schema registry configuration...
    schema_registry_conf = {
        'url': conf['schema.registry.url'],
        'basic.auth.user.info': conf['schema.registry.basic.auth.user.info']
    }

    # -> get SchemaRegistryClient
    sr: SchemaRegistryClient = SchemaRegistryClient(schema_registry_conf)

    # -> get all subjects registered with the Schema Registry based on regex pattern...
    subjects = list(filter(lambda s : re.match(".*eapi-cdp-.*", s) and not re.match(".*_il-.*", s), sr.get_subjects()))

    # -> loop over matched subjects, i.e. where subject := topic-{key,value}
    for subject in subjects:
        schema = sr.get_latest_version(subject)
        print(f"{Fore.LIGHTBLUE_EX}{subject}{Fore.WHITE} -> {Fore.YELLOW}version={schema.version}, id={schema.schema_id}{Style.RESET_ALL}")
        # print(schema.schema.schema_str)

def get_schema_info(subject: str, conf: dict) -> None:
    """
    checks if schema exists: if schema exists return AvroDeserializer else return StringDeserializer

    Args:
        subject (str): Subject refers to either a “<topic>-key” or “<topic>-value” depending on whether you are lookig for the key schema or the value schema
    
    See Also:
    `Confluent Schema Registry documentation <http://confluent.io/docs/current/schema-registry/docs/intro.html>
    """

    # get schema kind from subject, i.e. key || value
    kind = subject.split('-')[-1]

    # schema registry configuration...
    schema_registry_conf = {
        'url': conf['schema.registry.url'],
        'basic.auth.user.info': conf['schema.registry.basic.auth.user.info']
    }
    schema_registry_client: SchemaRegistryClient = SchemaRegistryClient(schema_registry_conf)

    # -> get schema information from SchemaRegistry
    try:
        versions: List = schema_registry_client.get_versions(subject)
        print(f"{Fore.GREEN}Subject: {subject}{Style.RESET_ALL} -> {Fore.CYAN}versioins: {len(versions)}{Style.RESET_ALL}")

        for v in versions:
            schema = schema_registry_client.get_version(subject, v)
            print(f"{Fore.YELLOW}version=[{schema.version}] -> id=[{Fore.BLUE}{schema.schema_id}{Fore.YELLOW}]{Style.RESET_ALL}")
            
            if args.verbose:
                print(f"{kind}-schema: \n{json.dumps(json.loads(schema.schema.schema_str), indent=2)}")

    except TypeError:
        print(f"{Fore.RED}TypeError: {kind}-schema: subject={subject} not in SchemaRegistry.{Style.RESET_ALL}")
    except SchemaRegistryError as Argument:
        print(f"{Fore.RED}SchemaRegistryError: {Argument}{Style.RESET_ALL}")

# main entry
if __name__ == '__main__':

    # Read arguments and configurations and initialize
    if len(sys.argv) == 1:  # fix the glitch with vscode run vs debug
        args = parser_lib.parse_args(vscode_run_args)
        if not args.quiet:
            print(f"{Fore.LIGHTGREEN_EX}Using module {sys.argv[0].split('/')[-1]} arguments: {Fore.LIGHTCYAN_EX}{vscode_run_args}{Style.RESET_ALL}")
    else:
        args = parser_lib.parse_args()
    config_file = args.config_file
    config_dict = parser_lib.read_cc_config(config_file)
    config_schema = parser_lib.schema_registry_params_from_config(config_dict)

    if args.verbose:
        print(f"{Fore.BLUE}Confluent Schema Cofiguration: {Style.RESET_ALL}\n{json.dumps(config_schema, indent=4)}")

    # -> we need a topic
    topic_name = args.topic

    #-> list all schemas if topic is empty...
    if topic_name == None:
        get_schema_subjects(config_schema)
    else:
        # => curl -u DNR2NTSCKSSEKXHT:dwavJew/xxijvMV9ZPXwmtOSg7kmBoPGqsiTrQ1W0sp1WM626vnz29KEIsN1kgBC https://psrc-4r0k9.westus2.azure.confluent.cloud/subjects/sit-eapi-cdp-ec_profile_il-value/versions/2
        get_schema_info(topic_name + "-key", config_schema)
        get_schema_info(topic_name + "-value", config_schema)

    exit()