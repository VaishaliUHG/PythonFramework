'''
Author: prem.thamarakshan
Python :3.9.8
Description : The execution of the test module.
'''

import pytest

if __name__ == '__main__':
    pytest.main(['tests/'])