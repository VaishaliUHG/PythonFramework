QA Automation AEP -UHG
Author: prem.thamarakshan
Project Version: 2.0

System Requirements:
1.python 3.9 or above.

Running the test scripts
1.Import the project to Pycharm.
2.Place the xlsx file in the input folder with 2 columns description, query for the dataset on which query needs to be performed.
3.In the config.ini file check for proper credentials especially password.
4.In the terminal within Pycharm check ("python -V" for windows and python3 -V for Mac) for knowing the python version.
5.After confirming python version in both terminals install the python dependencies within venv:
Windows: pip install openpyxl psycopg2 pytest
Mac : pip3 install openpyxl psycopg2 pytest
6.After ensuring installations are run we can run the automation module after placing the input file in the input directory as a .xlsx file
7.Run command in venv: python main.py
8.Find the log for the run in the log directory and the output result in output directory.
9.The log tail would contain the test summary of different test cases.

NOTE:
This test case was designed for custom test case according to requirement.
So it is not necessary it surpasses all the different scenarios.

Subject to new scenarios amendments will be made.