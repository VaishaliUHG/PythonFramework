'''
Author: prem.thamarakshan
Python :3.9.8
Description : necessary flag checks
'''

import pytest
import os


@pytest.fixture(scope='session', autouse=True)
def setup_tests(request):
    # Create the output folder if it doesn't exist
    os.makedirs('output', exist_ok=True)



