'''
Author: prem.thamarakshan
Python: 3.9.8
Description: The execution of the test case scenarios and writing the output
'''

import pytest
import os
import sys
from utils.database import get_db_connection, execute_query
from openpyxl import load_workbook
from openpyxl import Workbook
import re

# def extract_table_name(query):
#     table_name_regex = r'from\s+([^\s;(]+)'
#     match = re.search(table_name_regex, query, re.IGNORECASE)
#     if match:
#         return match.group(1)
#     else:
#         return None


def extract_table_name(query):
    if query is None:
        return None

    table_name_regex = r'from\s+([^\s;(]+)'
    match = re.search(table_name_regex, query, re.IGNORECASE)
    if match:
        return match.group(1)
    else:
        return None

def read_input_files(input_files):
    header = None
    data = []

    for file in input_files:
        file_path = os.path.join('input', file)
        workbook = load_workbook(file_path)
        sheet = workbook.active
        rows = sheet.iter_rows(values_only=True)

        if header is None:
            header = next(rows)

        for row in rows:
            data.append((file, *row))

    return ('DB Table Name',)+ header, data


@pytest.fixture
def db_connection():
    connection = get_db_connection()
    yield connection
    connection.close()

@pytest.fixture
def input_files():
    input_dir = 'input'
    files = [f for f in os.listdir(input_dir) if f.endswith('.xlsx')]
    return files

def write_output_file(header, results, file_name):
    output_dir = 'output'
    os.makedirs(output_dir, exist_ok=True)
    output_file_name = os.path.splitext(file_name)[0] + '_output.xlsx'
    file_path = os.path.join(output_dir, output_file_name)
    workbook = Workbook()
    sheet = workbook.active

    # Write the header
    sheet.append(header)

    # Write the data rows
    for row in results:
        sheet.append(row)

    # Save the workbook
    workbook.save(file_path)

def test_queries(db_connection, capsys, input_files):
    for file_name in input_files:
        header, data = read_input_files([file_name])
        results = []
        passed_tests = 0
        failed_tests = 0
        error_tests = 0

        for row in data:
            description = row[1]
            query = row[2]
            expected_output = row[3]  # Get the 'Expected Output' value from the row

            try:
                result = execute_query(db_connection, query)
                if isinstance(result, list) and len(result) == 1 and isinstance(result[0], tuple) and len(result[0]) == 1:
                    result = result[0][0]
                if isinstance(result, list) and len(result) == 0:
                    result = '[null]'
                else:
                    result = str(result)

                if expected_output is not None:
                    result_str = str(result)
                    expected_output_str = str(expected_output)
                    result_lower = result_str.lower()
                    expected_output_lower = expected_output_str.lower()
                    status = 'Pass' if result_lower == expected_output_lower else 'Fail'
                elif expected_output is None:
                    status = 'Pass' if (
                            result or result == '[null]' or
                            (isinstance(result, (list, tuple)) and all(v >= 0 for v in result))
                    ) else 'Fail'
                elif expected_output == '0':
                    status = 'Pass' if result == expected_output else 'Fail'



            except Exception as e:
                result = str(e)
                status = 'Error'
                error_tests += 1

            # Retrieve the DB table name from the query
            db_table_name = extract_table_name(query)

            print(f"DB Table Name: {db_table_name}")
            print(f"File: {file_name}")
            print(f"Description: {description}")
            print(f"Query: {query}")
            print(f"Actual Output: {result}")
            print(f"Expected Output: {expected_output}")  # Print the expected output
            print(f"Status: {status}")
            print("---------------------------------------------------------------------")

            results.append((db_table_name, description, query, expected_output, result, status))  # Add expected_output to the results

            if status == 'Pass':
                passed_tests += 1
            elif status == 'Fail':
                failed_tests += 1

        output_header = header + ('Actual Output(Result)', 'Status')
        write_output_file(output_header, results, file_name)  # Update the header for the output file

        log_dir = 'log'
        os.makedirs(log_dir, exist_ok=True)
        log_file_name = os.path.splitext(file_name)[0] + '_log.txt'
        log_file_path = os.path.join(log_dir, log_file_name)
        captured = capsys.readouterr()
        with open(log_file_path, 'a') as log_file:
            log_file.write(captured.out)

        total_tests = passed_tests + failed_tests + error_tests
        test_summary = f"\n-------------- Test Summary --------------\nTotal tests: {total_tests}\nPassed tests: {passed_tests}\nFailed tests: {failed_tests}\nError tests: {error_tests}\n-------------- End of Test Cases --------------\n"

        with open(log_file_path, 'a') as log_file:
            log_file.write(test_summary)

        sys.stdout.flush()

        # print(test_summary)

# Run pytest
# pytest.main(['-s'])
