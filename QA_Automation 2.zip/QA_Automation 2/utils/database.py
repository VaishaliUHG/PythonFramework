'''
Author: prem.thamarakshan
Python :3.9.8
Description : Database connection establish
'''

import configparser
import psycopg2

def get_db_connection():
    config = configparser.ConfigParser()
    config.read('config.ini')
    db_params = config['postgresql']

    connection = psycopg2.connect(
        host=db_params['host'],
        port=db_params['port'],
        database=db_params['database'],
        user=db_params['user'],
        password=db_params['password']
    )

    return connection

def execute_query(connection, query):
    cursor = connection.cursor()
    cursor.execute(query)
    result = cursor.fetchall()
    cursor.close()
    return result

